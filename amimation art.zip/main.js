let canvas = document.querySelector('#canvas');
let ctx = canvas.getContext('2d');
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
ctx.strokeStyle = 'pink';
ctx.lineWidth = 2;
ctx.shadowOffSetx = 10;
ctx.shadowOffSety = 10;
ctx.shadowBlur = 10;
ctx.shadowColor = 'blue';
let hue = 0;
let drowning = false;
//ctx.globalCompositeOperation = 'hue';





function drawShape(x, y,radias,inset,n){
   ctx.fillStyle = 'hsl('+ hue +',100%,50%)';
   ctx.beginPath();
   ctx.save();
   ctx.translate(x, y);
   ctx.moveTo(0,0 - radias);
  
   for(let i = 0; i < n; i++){
      ctx.rotate(Math.PI /n);
      ctx.lineTo(0,0 -  (radias * inset));
      ctx.rotate(Math.PI /n);
      ctx.lineTo(0,0 - radias);
      
   }

   ctx.restore();
   ctx.closePath();
   ctx.stroke();
   ctx.fill();
   
};

let radias = 50;
let inset = 0.5;
let n = 10;

drawShape(120, 120, radias,inset ,n );

let angle = 0;
window.addEventListener('mousemove',function(e){
   if(drowning){
      ctx.save();
     ctx.translate(e.x, e.y);
     ctx.rotate(angle);
      hue+=3;
      angle+= 0.5;
      drawShape(0, 0, radias,inset, n );
      ctx.restore();
   }
   
});
window.addEventListener('mousedown',function(){
   drowning = true;
})
window.addEventListener('mouseup',function(){
   drowning = false;
})




